CREATE DATABASE IF NOT EXISTS `tcprelay` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tcprelay`;

DROP TABLE IF EXISTS `TE_DEVICE_CMD`;
CREATE TABLE TE_DEVICE_CMD
(
  `SEQ` int(10) NOT NULL AUTO_INCREMENT,
  `EQ_MAKER` varchar(128) NOT NULL COMMENT '제작사',
  `EQ_TYPE` varchar(50) NOT NULL COMMENT '장치 종류',
  `EQ_NM` varchar(128) NOT NULL COMMENT '한글 이름',
  `EQ_VERSION` varchar(10) NOT NULL COMMENT 'cmd 버전',
  `CMD_TYPE` varchar(20) NOT NULL COMMENT '요청 커맨드 타입 set,req',
  `CMD_COLUMN` varchar(50) NOT NULL COMMENT '요청 커맨드',
  `CMD_COLUMN_NM` varchar(50) NOT NULL COMMENT '요청 커맨드',
  `COLUMN_UNIT` varchar(30) NOT NULL COMMENT '응답 단위',
  `BASE_RES_VALUE` varchar(30) NOT NULL COMMENT '기본값',
  `LOG_INS_DT` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`SEQ`)
 ) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='명령어정의';

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'temp','temp', '℃','21');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'humi','humi', '%','16');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'co2','co2', 'ppm','17');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'nh3','nh3', 'ppm','18');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'illum','illum', 'lux','19');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','S', 'temp','temp', '℃','21');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','S', 'ventil','ventil', '%','22');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatamt','eatamt', 'kg','23');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'setamt','setamt', 'kg','24');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'pigmnum','pigmnum', 'num','25');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatrate','eatrate', 'num','26');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'gyobaeday','gyobaeday', 'num','27');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'entercnt','entercnt', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'lastentertm','lastentertm', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'elecnum','elecnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'pigmnum','pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'gyobaedayy','gyobaeday', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'elecnum','elecnum', 'num','11');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatamt','eatamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'pigmnum','pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'inputday', 'inputday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'gyobaeday', 'gyobaeday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'bunmanday','bunmanday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'pigmnum', 'pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'workdiv','workdiv', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'inputday', 'inputday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'gyobaeday','gyobaeday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'bunmanday','bunmanday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'eatplan','eatplan', 'num','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'movecnt','movecnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'enterkg','enterkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'sailexpcnt','sailexpcnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'stankg','stankg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'avekg','avekg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'autodiv','autodiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'saildiv','saildiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'gatediv','gatediv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'groupid','groupid', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'updatTm','updateTm', 'ea','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'enterkg','enterkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'sailexpcnt','sailexpcnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'stankg','stankg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'autodiv','autodiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'saildiv','saildiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'gatediv','gatediv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'groupid','groupid', 'ea','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'V', '사료빈관리기', '1','R', 'restkg','restkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'V', '사료빈관리기', '1','R', 'updateTm','updateTm', 'kg','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'pigcnt', 'pigscnt','ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'aveday','aveday', 'day','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'stkg','stkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'grpstday','grpstday', 'day','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'feedamt','feedamt', 'cc','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'wateramt','wateramt', 'cc','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'wateramtsec','wateramtsec', 'sec','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'updateTm','updateTm', 'date','2019-08-21 12:00:00');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'pigcnt','pigscnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'aveday','aveday', 'day','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'stkg','stkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'grpstday','grpstday', 'date','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'wateramtsec','wateramtsec', 'sec','11');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','R', 'settemp','settemp', 'c','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','R', 'curtemp','curtemp', 'c','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','S', 'settemp','settemp','c','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'elecur', 'currnet', 'A','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'lgr', 'lgr', 'A','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'elecalarm', 'elecalarm', 'A','N');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'lgralarm', 'lgralarm', 'A','N');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'startTm', 'startTm', 'date','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'endTm', 'endTm', 'date','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','R', 'wateramt','하루음수량','ℓ','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','S', 'cycleset','주기', 'min','14');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','R', 'updateTm','측정시간', 'date','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '이지팜', 'I', '통합제어기', '1','R', 'reboot','reboot', 'c','11');