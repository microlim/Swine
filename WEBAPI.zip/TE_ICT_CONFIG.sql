-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 19-09-24 18:36
-- 서버 버전: 5.7.27-0ubuntu0.16.04.1
-- PHP 버전: 7.0.33-0ubuntu0.16.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `tcprelay`
--

CREATE DATABASE IF NOT EXISTS `tcprelay` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tcprelay`;

-- --------------------------------------------------------

--
-- 테이블 구조 `TE_ICT_CONFIG`
--

CREATE TABLE `TE_ICT_CONFIG` (
  `FARM_NO` varchar(64) NOT NULL COMMENT '농장번호',
  `IC_NO` varchar(64) NOT NULL COMMENT '통합제어기 번호',
  `IC_IP` varchar(64) NOT NULL COMMENT '통합제어기 IP',
  `IC_PORT` varchar(32) NOT NULL COMMENT '통합제어기 포트',
  `IC_SET_URL` varchar(128) NOT NULL COMMENT '모바일서버 환경설정 url',
  `IC_CMD_URL` varchar(128) NOT NULL COMMENT '제어기 환경설정 url',
  `MRECEV_URL` varchar(128) NOT NULL COMMENT '제어명령 url',
  `M_SET_URL` varchar(128) NOT NULL COMMENT '제어응답 수신 url',
  `LOG_INS_DT` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='통합제어기정보';

--
-- 테이블의 덤프 데이터 `TE_ICT_CONFIG`
--

INSERT INTO `TE_ICT_CONFIG` (`FARM_NO`, `IC_NO`, `IC_IP`, `IC_PORT`, `IC_SET_URL`, `IC_CMD_URL`, `MRECEV_URL`, `M_SET_URL`, `LOG_INS_DT`) VALUES
('1387', '1', '119.205.221.143', '5100', 'localhost', 'localhost', 'localhost', 'localhost', '2019-08-22 16:41:44');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `TE_ICT_CONFIG`
--
ALTER TABLE `TE_ICT_CONFIG`
  ADD PRIMARY KEY (`IC_NO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
