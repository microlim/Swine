CREATE DATABASE IF NOT EXISTS `tcprelay` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tcprelay`;


DROP TABLE IF EXISTS `TE_ICT_CONFIG`;
CREATE TABLE TE_ICT_CONFIG
(
  `FARM_NO` varchar(64) NOT NULL COMMENT '농장번호',
  `IC_NO` varchar(64) NOT NULL COMMENT '통합제어기 번호',
  `IC_IP` varchar(64) NOT NULL COMMENT '통합제어기 IP',
  `IC_PORT` varchar(32) NOT NULL COMMENT '통합제어기 포트',
  `IC_SET_URL` varchar(128) NOT NULL COMMENT '모바일서버 환경설정 url',
  `IC_CMD_URL` varchar(128) NOT NULL COMMENT '제어기 환경설정 url',
  `MRECEV_URL` varchar(128) NOT NULL COMMENT '제어명령 url',
  `M_SET_URL` varchar(128) NOT NULL COMMENT '제어응답 수신 url',
  `LOG_INS_DT` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`IC_NO`)
 ) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='통합제어기정보';

INSERT INTO `TE_ICT_CONFIG` (`FARM_NO`, `IC_NO`,`IC_IP`, `IC_PORT`, `IC_SET_URL`,`IC_CMD_URL`, `MRECEV_URL`,`M_SET_URL` ) VALUES ( '1387', '1','119.205.221.143', '5100','localhost','localhost','localhost','localhost');

DROP TABLE IF EXISTS `TE_DEVICE_LIST`;
CREATE TABLE TE_DEVICE_LIST
(
  `FARM_NO` varchar(10) NOT NULL COMMENT '농장번호',
  `IC_NO` varchar(32) NOT NULL COMMENT '농장통합장치ID',
  `EQ_TYPE` varchar(6) NOT NULL COMMENT '장치 종류',
  `EQ_ID` varchar(10) NOT NULL COMMENT '장치ID',
  `SEND_CYCLE` varchar(10) NOT NULL COMMENT '전송주기',
  `DONSA_CODE` varchar(6) NOT NULL COMMENT '돈사코드',
  `LOC_CODE` varchar(6) NOT NULL COMMENT '돈방코드',
  `USE_YN` varchar(1) NOT NULL COMMENT '사용여부',
  `ETC` varchar(128) NOT NULL COMMENT '기타정보',
  `LOG_INS_DT`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`FARM_NO`,`IC_NO`,`EQ_TYPE`,`EQ_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='설치장비정보';

INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'E', '1', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'E', '2', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'E', '3', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '1', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '10', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '11', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '12', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '13', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '14', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '15', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '16', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '17', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '18', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '19', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '2', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '20', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '21', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '22', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '23', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '24', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '25', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '26', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '27', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '28', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '29', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '3', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '30', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '31', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '32', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '33', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '34', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '35', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '36', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '37', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '38', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '39', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '4', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '40', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '41', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '42', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '43', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '44', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '45', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '46', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '47', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '48', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '49', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '5', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '50', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '51', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '52', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '53', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '54', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '55', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '56', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '57', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '58', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '59', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '6', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '3', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '61', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '62', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '63', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '64', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '65', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '66', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '67', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '68', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '69', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '7', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '70', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '8', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'F', '9', 3, '2', '13308', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '1', 3, '5', '13311', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '2', 3, '5', '13311', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '3', 3, '5', '13311', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '4', 3, '5', '13311', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '5', 3, '5', '13312', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '6', 3, '5', '13312', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'L', '7', 3, '5', '13312', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '1', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '10', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '2', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '3', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '4', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '5', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '6', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '7', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '8', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'S', '9', 3, '', '', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'V', '1', 3, '6', '13317', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'V', '2', 3, '9', '15415', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'W', '001', 3, '4', '6682', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'W', '002', 3, '6', '13317', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'W', '003', 3, '6', '15415', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'Y', '1', 3, '6', '15415', 'Y', '');
INSERT INTO `TE_DEVICE_LIST` (`farm_no`, `ic_no`, `eq_type`, `eq_id`, `send_cycle`, `donsa_code`, `loc_code`, `use_yn`, `etc`) VALUES ('1387', 'I1', 'Y', '2', 3, '6', '15415', 'Y', '');

INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'A', '1', 3, '3496', '18038', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '1', 3, '3496', '18034', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '2', 3, '3496', '18035', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '3', 3, '3496', '18036', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '4', 3, '3496', '18037', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '5', 3, '3496', '18038', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '6', 3, '3496', '18039', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'V', '9', 3, '3496', '18042', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '021', 3, '3496', '18034', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '022', 3, '3496', '18035', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '023', 3, '3496', '18036', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '024', 3, '3496', '18037', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '025', 3, '3496', '18038', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '026', 3, '3496', '18039', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '027', 3, '3496', '18040', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '028', 3, '3496', '18041', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'W', '029', 3, '3496', '18042', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I1', 'Y', '1', 3, '3496', '18038', 'Y', '');

INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'S', '1', 3, '', '', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'S', '2', 3, '', '', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'S', '3', 3, '', '', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'V', '10', 3, '3746', '18478', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'V', '11', 3, '3747', '18479', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'V', '12', 3, '3748', '18480', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'W', '031', 3, '3746', '18478', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'W', '032', 3, '3747', '18479', 'Y', '');
INSERT INTO TE_DEVICE_LIST (farm_no, ic_no, eq_type, eq_id, send_cycle, donsa_code, loc_code, use_yn, etc) VALUES ('1751', 'I2', 'W', '033', 3, '3748', '18480', 'Y', '');



DROP TABLE IF EXISTS `TE_DEVICE_SET_VALUE`;
CREATE TABLE TE_DEVICE_SET_VALUE
(
  `SEQ` int(10) NOT NULL AUTO_INCREMENT,
  `FARM_NO` varchar(10) NOT NULL COMMENT '농장번호',
  `IC_NO` varchar(32) NOT NULL COMMENT '농장통합장치ID',
  `EQ_TYPE` varchar(6) NOT NULL COMMENT '장치 종류',
  `EQ_ID` varchar(3) NOT NULL COMMENT '장치번호',
  `IC_ID` varchar(3) NOT NULL COMMENT '제어기번호',
  `CMD_TYPE` varchar(8) NOT NULL COMMENT '통신방식',
  `CMD_COLUMN` varchar(128) NOT NULL COMMENT '커맨드',
  `SET_VALUE` varchar(64) NOT NULL COMMENT '측정,설정값',
  `LOG_INS_DT`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`SEQ`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='장치설정값측정값';


INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'W', '1','1','R', 'wateramt','11');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'temp','26');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'humi', '26');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'co2', '17');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'nh3', '18');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'illum','19');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','R', 'ventil','20');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','S', 'temp', '21');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'S', '1','1','S', 'ventil','22');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'eatamt','31');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'setamt', '32');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'pigmnum', '33');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'eatrate', '34');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'gyobaeday', '35');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'entercnt', '36');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'lastentertm', '37');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'eatplan', '38');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','R', 'elecnum', '39');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'setamt','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'pigmnum','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'eatrate','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'gyobaeday','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'eatplan','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'E', '1','1','S', 'elecnum','11');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'eatamt','41');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'setamt', '42');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'pigmnum','43');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'eatrate','44');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'gyobaeday','45');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'bunmanday','46');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'workday','47');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','R', 'eatplan','48');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'setamt', '11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'pigmnum','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'eatrate', '11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'gyobaeday','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'bunmanday','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'F', '1','1','S', 'eatplan', '11');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'movecnt', '51');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'enterkg', '52');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'sailexpcnt', '53');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'stankg','54');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'avekg', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'autodiv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'saildiv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'gatediv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','R', 'groupid', '55');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'enterkg', '52');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'sailexpcnt', '53');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'stankg','54');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'autodiv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'saildiv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'gatediv', '55');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'Y', '1','1','S', 'groupid', '55');



INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'V', '1','1','R', 'restkg','61');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'pigcnt','62');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'aveday', '63');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'stkg', '64');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'wateramtsec','65');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'feedamt', '66');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','R', 'wateramt', '67');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','S', 'pigscnt','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','S', 'aveday','11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','S', 'stkg', '11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'L', '1','1','S', 'wateramtsec','11');


INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'C', '1','1','R', 'settemp','29');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'C', '1','1','R', 'curtemp', '28');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'C', '1','1','S', 'settemp','28');

INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'A', '1','1','R', 'eleccur', '11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'A', '1','1','R', 'lgr', 'no');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'A', '1','1','R', 'elecalarm', '11');
INSERT INTO `TE_DEVICE_SET_VALUE` (`FARM_NO`, `IC_NO`, `EQ_TYPE`,`EQ_ID`, `IC_ID`,`CMD_TYPE`, `CMD_COLUMN`,`SET_VALUE`) VALUES	( '1387','I1', 'A', '1','1','R', 'lgralarm', 'no');


DROP TABLE IF EXISTS `TE_DEVICE_CMD`;
CREATE TABLE TE_DEVICE_CMD
(
  `SEQ` int(10) NOT NULL AUTO_INCREMENT,
  `EQ_MAKER` varchar(128) NOT NULL COMMENT '제작사',
  `EQ_TYPE` varchar(50) NOT NULL COMMENT '장치 종류',
  `EQ_NM` varchar(128) NOT NULL COMMENT '한글 이름',
  `EQ_VERSION` varchar(10) NOT NULL COMMENT 'cmd 버전',
  `CMD_TYPE` varchar(20) NOT NULL COMMENT '요청 커맨드 타입 set,req',
  `CMD_COLUMN` varchar(50) NOT NULL COMMENT '요청 커맨드',
  `CMD_COLUMN_NM` varchar(50) NOT NULL COMMENT '요청 커맨드',
  `COLUMN_UNIT` varchar(30) NOT NULL COMMENT '응답 단위',
  `BASE_RES_VALUE` varchar(30) NOT NULL COMMENT '기본값',
  `LOG_INS_DT` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`SEQ`)
 ) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='명령어정의';

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'temp','temp', '℃','21');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'humi','humi', '%','16');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'co2','co2', 'ppm','17');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'nh3','nh3', 'ppm','18');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'illum','illum', 'lux','19');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'ventil','ventil', '%','20');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','S', 'temp','temp', '℃','21');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '지원', 'S', '환경센서', '1','S', 'ventil','ventil', '%','22');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatamt','eatamt', 'kg','23');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'setamt','setamt', 'kg','24');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'pigmnum','pigmnum', 'num','25');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatrate','eatrate', 'num','26');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'gyobaeday','gyobaeday', 'num','27');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'entercnt','entercnt', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'lastentertm','lastentertm', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'elecnum','elecnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'pigmnum','pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'gyobaedayy','gyobaeday', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'E', '군사급이기', '1','S', 'elecnum','elecnum', 'num','11');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatamt','eatamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'pigmnum','pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'inputday', 'inputday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'gyobaeday', 'gyobaeday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'bunmanday','bunmanday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'eatplan','eatplan', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','R', 'updateTm','updateTm', 'num','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'setamt','setamt', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'pigmnum', 'pigmnum', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'eatrate','eatrate', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'workdiv','workdiv', 'num','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'inputday', 'inputday','num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'gyobaeday','gyobaeday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'bunmanday','bunmanday', 'num','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'F', '모돈자동급이기', '1','S', 'eatplan','eatplan', 'num','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'movecnt','movecnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'enterkg','enterkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'sailexpcnt','sailexpcnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'stankg','stankg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'avekg','avekg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'autodiv','autodiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'saildiv','saildiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'gatediv','gatediv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'groupid','groupid', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'updatTm','updateTm', 'ea','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'enterkg','enterkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'sailexpcnt','sailexpcnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'stankg','stankg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'autodiv','autodiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'saildiv','saildiv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'gatediv','gatediv', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'Y', '돈선별기', '1','R', 'groupid','groupid', 'ea','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'V', '사료빈관리기', '1','R', 'restkg','restkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'V', '사료빈관리기', '1','R', 'updateTm','updateTm', 'kg','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'pigcnt', 'pigscnt','ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'aveday','aveday', 'day','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'stkg','stkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'grpstday','grpstday', 'day','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'feedamt','feedamt', 'cc','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'wateramt','wateramt', 'cc','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'wateramtsec','wateramtsec', 'sec','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','R', 'updateTm','updateTm', 'date','2019-08-21 12:00:00');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'pigcnt','pigscnt', 'ea','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'aveday','aveday', 'day','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'stkg','stkg', 'kg','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'grpstday','grpstday', 'date','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'L', '액상자돈급이기', '1','S', 'wateramtsec','wateramtsec', 'sec','11');


INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','R', 'settemp','settemp', 'c','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','R', 'curtemp','curtemp', 'c','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '시트로닉스', 'C', '냉방기', '1','S', 'settemp','settemp','c','11');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'elecur', 'currnet', 'A','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'lgr', 'lgr', 'A','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'elecalarm', 'elecalarm', 'A','N');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'lgralarm', 'lgralarm', 'A','N');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'startTm', 'startTm', 'date','2019-08-21 12:00:00');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '에프에스', 'A', '정전화재센서', '1','R', 'endTm', 'endTm', 'date','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','R', 'wateramt','하루음수량','ℓ','11');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','S', 'cycleset','주기', 'min','14');
INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '코마스', 'W', '음수관리기', '1','R', 'updateTm','측정시간', 'date','2019-08-21 12:00:00');

INSERT INTO `TE_DEVICE_CMD` (`EQ_MAKER`, `EQ_TYPE`, `EQ_NM`, `EQ_VERSION`,`CMD_TYPE`, `CMD_COLUMN`,`CMD_COLUMN_NM`,`COLUMN_UNIT`,`BASE_RES_VALUE`) VALUES	( '이지팜', 'I', '통합제어기', '1','R', 'reboot','reboot', 'c','11');