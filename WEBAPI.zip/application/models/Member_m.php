<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * todo 모델
 *
 * @author Jongwon Byun <advisor@cikorea.net>
 * @version 1.0
 */
class Member_m extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

	/**
	 * todo 조회
	 */
    function get_view($id)
    {
    	$sql = "SELECT * FROM users WHERE id='".$id."'";

		$query = $this->db->query($sql);

     	//내용 반환
	    $result = $query->row();

    	return $result;
    }

	/**
	 * todo 목록 가져오기
	 */
    function get_list()
    {
		$sql = "SELECT * FROM users";

		$query = $this->db->query($sql);

		$result = $query->result();

    	return $result;
    }

	/**
	 * todo 입력
  `ucnt` int(10) NOT NULL AUTO_INCREMENT,
  `ugroup` int(10) NOT NULL DEFAULT '1' COMMENT '유저그룹',
  `id` varchar(50) NOT NULL COMMENT '아이디',
  `password` varchar(50) NOT NULL COMMENT '비밀번호',
  `name` varchar(50) NOT NULL COMMENT '이름',
  `email` varchar(50) NOT NULL COMMENT '이메일',
  `reg_date` datetime NOT NULL COMMENT '가입일',
  `etcinfo` varchar(50) NOT NULL COMMENT '기타정보',
	 */
	function insert_user($ugroup, $id, $password,$name,$email,$etcinfo)
 	{
		$reg_date = date("Y-m-d H:i:s") ;
	
		$sql = "INSERT INTO users ( ugroup, id, password, name, email, reg_date, etcinfo) VALUES (".$ugroup.", '".$id."', '".$password."', '".$name."','".$email."', '".$reg_date."', '".$etcinfo."')";
		if( $id != "" )
		{
			$query = $this->db->query($sql);
		}
 	}

	/**
	 * todo 삭제
	 */
	function delete_user($id)
 	{
		$sql = "DELETE FROM users WHERE id ='".$id."'";

		$query = $this->db->query($sql);
 	}
}

/* End of file todo_m.php */
/* Location: ./application/models/todo_m.php */