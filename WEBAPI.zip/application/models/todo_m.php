<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * todo 모델
 *
 * @author Jongwon Byun <advisor@cikorea.net>
 * @version 1.0
 */
class todo_m extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

	/**
	 * todo 조회
	 */

	function get_ftekconfig()
    {
    	$sql = "SELECT * FROM ftekconfig";

		$query = $this->db->query($sql);

     	//내용 반환
	    $result = $query->row();

    	return $result;
    }

	function update_ftekconfig($sqldata)
 	{
		$query = $this->db->update('ftekconfig',$sqldata);
		if($this->db->affected_rows() > 0) {
 
		}else{
		
		}
	}

    function get_view($id)
    {
    	$sql = "SELECT * FROM deliverylog WHERE fuid='".$id."' and dcode=255";

		$query = $this->db->query($sql);

     	//내용 반환
	    $result = $query->row();

    	return $result;
    }

	/**
	 * todo 목록 가져오기
	 */
    function get_todayOrderList()
    {
		$sql = "SELECT * FROM deliverylog where date(ddate)=date(now()) and dcode<255  order by ddate desc";

		$query = $this->db->query($sql);

		$result = $query->result();
   	
		return $result;
    }

    function get_todayOrderCount()
    {
		$sql = "SELECT * FROM deliverylog where date(ddate)=date(now()) and dcode<255  order by ddate desc";

		$query = $this->db->query($sql);

		return $query ;
    }

    function get_dayOrderCount($inDate)
    {
		$sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."') and dcode<255 order by ddate desc";
		
		$query = $this->db->query($sql);

		return $query ;
    }

   function get_dayOrderCountShop($inDate,$shopid)
    {
		//$sql = "SELECT * FROM orderlog where date(odate)=date('".$inDate."') and shopid='".$shopid."'";
		$sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."') and fuid='".$shopid."' and dcode<255 order by ddate desc";
		
		$query = $this->db->query($sql);

		return $query ;
    }

   function get_dayOrderCountShopResult($inDate,$shopid)
    {
		$sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."') and fuid='".$shopid."' and dcode<255 order by ddate desc";
		
		$query = $this->db->query($sql);

		$result = $query->result();
   	
		return $result;
    }

   function get_dayOrderCountShopnameResult($inDate,$shopna)
    {
	   $sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."') and fuid='".$shopna."' and dcode<255 order by ddate desc";

	   if( strcmp( $shopna,"전체") == 0 )
		$sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."')  order by ddate desc";
	   else 
        $sql = "SELECT * FROM deliverylog where date(ddate)=date('".$inDate."') and fuid='".$shopna."' and dcode<255 order by ddate desc";

		$query = $this->db->query($sql);

		$result = $query->result();
   	
		return $result;
    }

    function get_MemberList($id)
    {
		$sql = "select * from shopuser where id='".$id."' ";
		$query = $this->db->query($sql);
		$result = 'none' ;
		if($query->num_rows()>0){
			 
			foreach ($query->result_array() as $row)
			{
				$result = $row['shopname'];
			}
		}		
		return $result;
    }

    function get_MemberidListByName($name)
    {
		$sql = "select * from shopuser where shopname='".$name."'";
		$query = $this->db->query($sql);
		$result = 'none' ;
		if($query->num_rows()>0){
			 
			foreach ($query->result_array() as $row)
			{
				$result = $row['id'];
			}
		}		
		return $result;
    }
    function get_BonMemberList()
    {
		$sql = "select * from shopuser where shopname LIKE '본%'";
		$query = $this->db->query($sql);
		$result = $query->result();
  		return $result;
    }

    function get_AllMemberList()
    {
		$sql = "select * from shopuser";
		$query = $this->db->query($sql);
		$result = $query->result();
  		return $result;
    }

    function set_insertdayOrderCountShop($shopname,$shopid,$ordercnt,$odate)
    {
	
			
		$sql = "select * from summary where shopid='".$shopid."' and date='".$odate."'";
		$query = $this->db->query($sql);
		
		if($query->num_rows()>0)
		{
			$sql2 = "update summary set count=".$ordercnt." where shopid='".$shopid."' and date='".$odate."'";
			$this->db->query($sql2);
		} else {
			$sql2 = "INSERT INTO summary (shopname, shopid, count, date) VALUES ('".$shopname."','".$shopid."','".$ordercnt."','".$odate."')";
			$this->db->query($sql2);
		}
		
    }

    function set_insertTotalCountShop($shopname,$shopid,$ordercnt,$odate)
    {
		$sql = "select * from total_sum where shopid='".$shopid."' and date='".$odate."'";
		$query = $this->db->query($sql);
		
		if($query->num_rows()>0)
		{
			$sql2 = "update total_sum set count=".$ordercnt." where shopid='".$shopid."' and date='".$odate."'";
			$this->db->query($sql2);
		} else {
			$sql2 = "INSERT INTO total_sum (shopname, shopid, count, date) VALUES ('".$shopname."','".$shopid."','".$ordercnt."','".$odate."')";
			$this->db->query($sql2);
		}
		
    }

    function get_TotalSummaryTable($sname,$gdate)
    {
		$sql = "SELECT * FROM total_sum where shopname='".$sname."' and date like '".$gdate."%'";

		$query = $this->db->query($sql);

		$result = $query->result();
   	
		return $result;
    }

    function get_todaySummaryTable()
    {
		$sql = "SELECT * FROM summary order by count desc";

		$query = $this->db->query($sql);

		$result = $query->result();
   	
		return $result;
    }

	function delete_summary()
 	{
		$sql = "DELETE FROM summary";

		$query = $this->db->query($sql);
 	}
}

/* End of file todo_m.php */
/* Location: ./application/models/todo_m.php */