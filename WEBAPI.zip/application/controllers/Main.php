<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * todo controller.
 *
 * @author Jongwon, Byun <advisor@cikorea.net>
 */
class Main extends CI_Controller {

 	function __construct()
	{
		parent::__construct();
		$this->load->database();
        //$this->load->model('todo_m');
		$this->load->helper('url');


		


		
	}

	public function _remap($method)
 	{
 		//헤더 include
        $this->load->view('swcheader_v');
		$this->load->view('swcleftmenu_v');

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}

		//푸터 include
		$this->load->view('swcfooter_v');
    }

	/**
	 * 주소에서 메소드가 생략되었을 때 실행되는 기본 메소드
	 */
	public function index()
	{
		
	}

	/**
	 * todo 조회
	 */
	function view()
 	{
 		//todo 번호에 해당하는 데이터 가져오기
 	}

	/**
	 * todo 목록
	 */

	function getdb_devlist()
    {
		//$query = $this->db->get('TE_DEVICE_LIST');
   
		$sqlstr = "SELECT * FROM TE_DEVICE_LIST AS x JOIN TE_CODE_DEF AS y ON x.EQ_TYPE=y.CODE" ;
		$query = $this->db->query($sqlstr);	

		$result = $query->result();
	   	return $result;
    }

	public function devlists()
	{
	
		if ( $_POST )
  		{
		  // 전체 주기 설정 처리 
		  //UPDATE TE_DEVICE_LIST SET SEND_CYCLE='6' WHERE 1
			$find_CYCLE = $this->input->post('ALL_CYCLE', TRUE); 

			$sqlstr = "UPDATE TE_DEVICE_LIST SET SEND_CYCLE='".$find_CYCLE."' WHERE 1" ;
			$query = $this->db->query($sqlstr);	
			
			echo '<script>alert("변경되었습니다!");</script>';		
		} 
			

		$getdata['list'] = $this->getdb_devlist();
		$this->load->view('ict/list_v',$getdata);

	
	}

	public function ICTrestart()
	{
		$address = "119.205.221.143";                                                 // 접속할 IP //
		$port = 5100;                                                                         // 접속할 PORT //

		$query = $this->db->get('TE_ICT_CONFIG');
		
		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();

			$address=$row->IC_IP;
			$port=(int)$row->IC_PORT;
			
		} else $address = $_SERVER["SERVER_ADDR"] ;


		 $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP); // TCP 통신용 소켓 생성 //
		 if ($socket == false) {
			 $retmess['error']='ERROR_80' ;
			 return;	
		 } 
		 
		$result = socket_connect($socket, $address, $port);           // 소켓 연결 및 $result에 접속값 지정 //
		 if ($result == false) {
			 $retmess['error']='ERROR_81' ;
			 return ;
		 }
// "{ \"type\": \"reset\", \"farmNo\": \"1387\", \"icNo\": \"I1\", \"cmdString\": [ { \"eqId\": \"all\", \"reset\": \"0\" }] }"



		$jsonstr = "{ \"type\": \"reset\", \"farmNo\": \"1387\", \"icNo\": \"I1\", \"cmdString\": [ { \"eqId\": \"all\", \"reset\": \"0\" }] }" ;
		socket_write($socket, $jsonstr, strlen($jsonstr)); // 실제로 소켓으로 보내는 명령어 //
		
		socket_close($socket);
	}

// SELECT x.EQ_TYPE, y.HNAME FROM TE_DEVICE_LIST AS x JOIN TE_CODE_DEF AS y ON x.EQ_TYPE=y.CODE WHERE  x.FARM_NO='1387' and x.EQ_TYPE='E' and x.EQ_ID='1'

	function getdb_devinfo($farm_no,$eq_type,$eq_id)
    {
		
		//$this->db->where('FARM_NO', $farm_no );
		//$this->db->where('EQ_TYPE', $eq_type );
		//$this->db->where('EQ_ID', $eq_id );
		//$query = $this->db->get('TE_DEVICE_LIST');

		
		//$sql = "SELECT * FROM users WHERE id='".$id."'";
		$sqlstr = "SELECT * FROM TE_DEVICE_LIST AS x JOIN TE_CODE_DEF AS y ON x.EQ_TYPE=y.CODE WHERE  x.FARM_NO='".$farm_no."' and x.EQ_TYPE='".$eq_type."' and x.EQ_ID='".$eq_id."'" ;
		$query = $this->db->query($sqlstr);	
		
		
		//echo $equtype.",".$cmdtype.",".$cmdstr ;

		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();
			
			
			return $row;
		}		
	
	    return null;
    }

	//$this->uri->segment(3);
	//SELECT EQ_TYPE,EQ_NM FROM `TE_DEVICE_CMD` group by EQ_TYPE
	public function devinfo()
	{

		if ( $_POST )
  		{
			
			$find_FARM_NO="0000";
			$find_FARM_NO = $this->input->post('FARM_NO', TRUE); 
			$find_IC_NO = $this->input->post('IC_NO', TRUE); 
			$find_EQ_TYPE = $this->input->post('EQ_TYPE', TRUE); 
			$find_EQ_ID = $this->input->post('EQ_ID', TRUE); 
			$find_SEND_CYCLE = $this->input->post('SEND_CYCLE', TRUE); 
			$find_DONSA_CODE = $this->input->post('DONSA_CODE', TRUE); 
			$find_LOC_CODE = $this->input->post('LOC_CODE', TRUE); 
			$find_USE_YN = $this->input->post('USE_YN', TRUE); 
			
			if( strcmp($find_FARM_NO,'0000' ) != 0 )
			{
			
				$postData= array(
					'FARM_NO' => $find_FARM_NO, 
					'IC_NO' =>$find_IC_NO,
					'EQ_TYPE' =>$find_EQ_TYPE,
					'EQ_ID' =>$find_EQ_ID,
					'SEND_CYCLE' =>$find_SEND_CYCLE,
					'DONSA_CODE' =>$find_DONSA_CODE,
					'LOC_CODE' =>$find_LOC_CODE,
					'USE_YN' =>$find_USE_YN,

				);

				$this->db->where('FARM_NO', $find_FARM_NO );
				$this->db->where('EQ_TYPE', $find_EQ_TYPE );
				$this->db->where('EQ_ID', $find_EQ_ID );				
				$this->db->update('TE_DEVICE_LIST', $postData);

				echo '<script>alert("저장되었습니다!");</script>';	

				$getdata['data']= $this->getdb_devinfo( $find_FARM_NO,$find_EQ_TYPE,$find_EQ_ID);
				$getdata['nmdata']= $this->getdb_DevNM_Find($find_EQ_TYPE) ;
			
				$this->load->view('ict/writedev_v',$getdata);
			
			} else {

				echo '<script>alert("처리 에러!");</script>';	
			}
			


		} else {

			$dbdata = $this->getdb_config(); 

			//echo $dbdata->FARM_NO;
			

			$getdata['data']= $this->getdb_devinfo($dbdata->FARM_NO,$this->uri->segment(3),$this->uri->segment(4));
			$getdata['nmdata']= $this->getdb_DevNM_Find($this->uri->segment(3)) ;
		
			$this->load->view('ict/writedev_v',$getdata);
		}
	}
	
	function getdb_DevNM_Read()
    {
		
		$sql = "SELECT EQ_TYPE,EQ_NM FROM TE_DEVICE_CMD group by EQ_TYPE";
		$query = $this->db->query($sql);		
		
		$result = $query->result();
		/*
		foreach ($query->result_array() as $row)
		{

			echo $row['EQ_NM'];

		}
		*/
  		return $result ;
    }

	function getdb_DevNM_Find($eqtype)
    {
		
		$sql = "SELECT EQ_TYPE,EQ_NM FROM TE_DEVICE_CMD group by EQ_TYPE";
		$query = $this->db->query($sql);			
		

		$result = 'none' ;
		if($query->num_rows()>0)
		{
			foreach ($query->result_array() as $row)
			{
				if( strcmp($eqtype,$row['EQ_TYPE']) == 0)
				{
					$result = $row['EQ_NM'];
					//echo $result ;
				}
			}
		}		
		return $result;

    	
    }

	function getdb_config()
    {
		$query = $this->db->get('TE_ICT_CONFIG');
     	//내용 반환
	    $result = $query->row();

    	return $result;
    }

	public function config()
	{
	
		
		if ( $_POST )
  		{
			$find_FARM_NO="0000";
			$find_FARM_NO = $this->input->post('FARM_NO', TRUE); 
			$find_IC_NO = $this->input->post('IC_NO', TRUE); 
			$find_IC_IP = $this->input->post('IC_IP', TRUE); 
			$find_IC_PORT = $this->input->post('IC_PORT', TRUE); 
			
			if( strcmp($find_FARM_NO,'0000' ) != 0 )
			{
			
				$postData= array(
					'FARM_NO' => $find_FARM_NO, 
					'IC_NO' =>$find_IC_NO,
					'IC_IP' =>$find_IC_IP,
					'IC_PORT' =>$find_IC_PORT,

				);

				$this->db->update('TE_ICT_CONFIG', $postData);

				
			} 


			echo '<script>alert("저장되었습니다!");</script>';	

			$dbdata['data'] = $this->getdb_config();
			$this->load->view('ict/write_v',$dbdata);

/*
			$scrver = $this->input->post('scrver', TRUE); 
			$enable = $this->input->post('enable', TRUE); 

		
			$configdata = array(
				'scrver'  => $scrver ,
				'enable' => $enable 

			);

			$this->todo_m->update_ftekconfig($configdata); 
			$data['views'] = $this->todo_m->get_ftekconfig();
			$this->load->view('ftekconfig/write_v', $data);
*/
		} else {

		
			$dbdata['data'] = $this->getdb_config();
			$this->load->view('ict/write_v',$dbdata);

		}
	}


	/**
	 * todo 입력
	 */
	function write()
 	{

 	}

	/**
	 * todo 삭제
	 */
	function delete()
 	{
 		//게시물 번호에 해당하는 게시물 삭제
 	}

}

/* End of file main.php */
/* Location: ./application/controllers/main.php */