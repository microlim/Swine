<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

class ITGC extends REST_Controller {

	function __construct()
	{
        // Construct the parent class
        parent::__construct();
 
		$this->load->database();
  
		
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        
    }

	public function test_post()
	{
		//echo $this->input->raw_input_stream ;
		//echo $ip = $_SERVER['REMOTE_ADDR'];
		
		$find_cmd= $this->post('cmd');
		
		
		if( is_array($find_cmd) )
		{
			//echo count($find_cmd) ;
			//echo '43210';
			echo $find_cmd;
		} else {

			echo $find_cmd;
		}

	}

	public function test_get()
	{
		echo $this->input->raw_input_stream ;
	}

	public function search_cmd($equtype,$cmdtype,$cmdstr)
 	{
		$this->db->where('type', $equtype );
		$this->db->where('ctype', $cmdtype );
		$this->db->where('cmd', $cmdstr );
		$query = $this->db->get('deviceinfo');
		
		//echo $equtype.",".$cmdtype.",".$cmdstr ;

		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();
			$dbvalue=$row->value;
			
			return $dbvalue;
		}		

		//echo '<script>alert("no!");</script>';
		return null;
 	}

	public function onlyHanAlpha($subject) {
		$pattern = '/([\xEA-\xED][\x80-\xBF]{2}|[a-zA-Z])+/';
		preg_match_all($pattern, $subject, $match);
		return implode('', $match[0]);
	}

	//SELECT `SET_VALUE` FROM `TE_DEVICE_SET_VALUE` WHERE FARM_NO='1387' AND IC_NO='I1' AND EQ_TYPE='W' AND EQ_ID='1' AND CMD_COLUMN='wateramt'
	
	public function getDeviceValue($farmno,$icId,$eqType,$eqId,$cmdcolumn)
 	{
		$this->db->where('FARM_NO', $farmno );
		$this->db->where('IC_NO', $icId );
		$this->db->where('EQ_TYPE', $eqType );
		$this->db->where('EQ_ID', $eqId );

		$this->db->where('CMD_COLUMN', $cmdcolumn);
		$query = $this->db->get('TE_DEVICE_SET_VALUE');
		
		//echo $equtype.",".$cmdtype.",".$cmdstr ;

		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();

			$dbvalue=$row->SET_VALUE;
			
			return $dbvalue;
		}		

		//echo '<script>alert("no!");</script>';
		return '0';
 	}

	public function getDeviceDate($farmno,$icId,$eqType,$eqId,$cmdcolumn)
 	{
		$this->db->where('FARM_NO', $farmno );
		$this->db->where('IC_NO', $icId );
		$this->db->where('EQ_TYPE', $eqType );
		$this->db->where('EQ_ID', $eqId );
		$this->db->where('CMD_COLUMN', $cmdcolumn);
		$query = $this->db->get('TE_DEVICE_SET_VALUE');
		
		//echo $equtype.",".$cmdtype.",".$cmdstr ;

		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();
			
			$dbvalue=$row->LOG_INS_DT;
			
			
			return $dbvalue;
		}		

		//echo '<script>alert("no!");</script>';
		return '0';
 	}

	public function setDeviceValue($farmno,$icId,$eqType,$eqId,$cmdcolumn,$setvalue)
 	{
		$setdata = array(
        'SET_VALUE' => $setvalue,
		);	
		
		$this->db->where('FARM_NO', $farmno );
		$this->db->where('IC_NO', $icId );
		$this->db->where('EQ_TYPE', $eqType );
		$this->db->where('EQ_ID', $eqId );
		$this->db->where('CMD_COLUMN', $cmdcolumn);
		$this->db->update('TE_DEVICE_SET_VALUE',$setdata);
		
		//echo $equtype.",".$cmdtype.",".$cmdstr ;
		$query = $this->db->get('TE_DEVICE_SET_VALUE');
		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();
			$dbvalue=$row->SET_VALUE;
			
			return $dbvalue;
		}		

		//echo '<script>alert("no!");</script>';
		return '0';
 	}

	public function getCountDeviceE($eqId)
	{

		$sql = "SELECT * FROM TE_DEVICE_SET_VALUE WHERE EQ_TYPE='E' and EQ_ID like '".$eqId."-%' order by EQ_ID asc";
		$query = $this->db->query($sql);		
		
		$result = $query->result();
		
		$rescnt=0 ;
		foreach ($query->result_array() as $row)
		{
			$curcnt=  (int)substr( $row['EQ_ID'] , strpos($row['EQ_ID'], "-" )+1 );

			if( $rescnt < $curcnt ) $rescnt = $curcnt ;
		}
		
  		return $rescnt ;
 	}
	
	public function getEtypeDeviceValue($eqId,$eqIdcnt)
	{

		$sql = "SELECT * FROM TE_DEVICE_SET_VALUE WHERE EQ_TYPE='E' and EQ_ID ='".$eqId."-".$eqIdcnt."' order by EQ_ID asc";
		$query = $this->db->query($sql);		
		
		$result = $query->result();
		
		return $result ;
 	}
	
	public function cfg_post()
	{
		$retmess = array();
		
		$find_type="none";
		$find_farmno="none";
		$find_icno="none";
		$find_icip="none";
		$find_icport="none";
		$find_icseturl="none";
		$find_iccmdurl="none";
		$find_mrecevurl="none";
		$find_mseturl="none";
		
	
		$find_ok=0;

		$query = $this->db->get('TE_ICT_CONFIG');
		
		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();
			$find_farmno=$row->FARM_NO;
			$find_icno=$row->IC_NO;
			$find_icip=$row->IC_IP;
			$find_icport=$row->IC_PORT;
			$find_icseturl=$row->IC_SET_URL;
			$find_iccmdurl=$row->IC_CMD_URL;
			$find_mrecevurl=$row->MRECEV_URL;
			$find_mseturl=$row->M_SET_URL;
			
		}		

		//echo '<script>alert("no!");</script>';		
	
	
		

		$retmess['FARM_NO']=$find_farmno ;
		$retmess['IC_NO']=$find_icno ;
		$retmess['IC_IP']=$find_icip ;
		$retmess['IC_PORT']=$find_icport ;
		
		$retmess['IC_SET_URL']=$find_icseturl ;
		$retmess['IC_CMD_URL']=$find_iccmdurl ;
		$retmess['MRECEV_URL']=$find_mrecevurl ;
		$retmess['M_SET_URL']=$find_mseturl ;
		


		$this->set_response($retmess, REST_Controller::HTTP_OK); 

	}	
	
	public function tcp_post()
	{
		$retmess = [
		'type' => "res",
			];
		
		$find_type="none";
		$find_farmno="none";
		$find_icno="none";
		$find_equno="none";
		$find_cmd="none";
		$find_value="none";
		$find_time="none";
	
		$find_ok=0;
	
		$find_type = $this->post('type') ;
		$find_farmno =  $this->post('farmNo') ;
		$find_icno =  $this->post('icNo') ;
		$find_equno= $this->post('eqId');
		$find_cmd= $this->post('cmdString');
		$find_time= $this->post('regTm');
		$find_value=$this->post('value');		
		

		$retmess['farmNo']=$find_farmno ;
		$retmess['icNo']=$find_icno ;
		$retmess['eqId']=$find_equno ;
		$retmess['cmdString']='accept' ;
		$retmess['value']='0' ;

		
		$retmess['regTm']=$find_time ;
		
		$address = "119.205.221.143";                                                 // ������ IP //
		$port = 5100;     

		$query = $this->db->get('TE_ICT_CONFIG');
		
		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();

			$address=$row->IC_IP;
			$port=(int)$row->IC_PORT;
			
		}		


                                                                    // ������ PORT //
		 
		 $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP); // TCP ��ſ� ���� ���� //
		 if ($socket == false) {
			 $retmess['regTm']='ERROR_80' ;
		  
		 } 
		 
		$result = socket_connect($socket, $address, $port);           // ���� ���� �� $result�� ���Ӱ� ���� //
		 if ($result == false) {
			 $retmess['regTm']='ERROR_81' ;
		 }

		$i = $this->input->raw_input_stream ;  //�������� �ϴ� ���� //
		socket_write($socket, $i, strlen($i)); // ������ �������� ������ ���ɾ� //
		
		//echo "<br>"; ����ϼ��� �����    
		//$input = socket_read($socket, 1024) or die("Could not read from Socket\n");  // �������� ���� ���� REQUEST ������ $input�� ���� //
		//echo "<br>";
		//echo $input;  //REQUEST ���� ���//
		socket_close($socket);

		$this->set_response($retmess, REST_Controller::HTTP_OK); 

	}
	public function cmdold_post()
	{

	$retmess = [
		'type' => "res",
			];
		
		$find_type="none";
		$find_farmno="none";
		$find_icno="none";
		$find_equno="none";
		$find_cmd="none";
		$find_value="none";
		$find_time="none";
	
		$find_ok=0;
	
		$find_type = $this->post('type') ;
		$find_farmno =  $this->post('farmNo') ;
		$find_icno =  $this->post('icNo') ;
		$find_equno= $this->post('eqId');
		$find_cmd= $this->post('cmdString');
		$find_time= $this->post('regTm');
		$find_value=$this->post('value');		
		

		$retmess['farmNo']=$find_farmno ;
		$retmess['icNo']=$find_icno ;
		$retmess['eqId']=$find_equno ;
		$retmess['cmdString']='accept' ;
		$retmess['value']='0' ;

		
		$retmess['regTm']=$find_time ;
		
		
		$address = "119.205.221.143";                                                 // ������ IP //
		$port = 5100;                                                                         // ������ PORT //

		$query = $this->db->get('TE_ICT_CONFIG');
		
		if ($query->num_rows()>0)
		{
			//echo '<script>alert("ok!");</script>';
			$row = $query->row();

			$address=$row->IC_IP;
			$port=(int)$row->IC_PORT;
			
		}				 

		 $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP); // TCP ��ſ� ���� ���� //
		 if ($socket == false) {
			 $retmess['regTm']='ERROR_80' ;
		  
		 } 
		 
		$result = socket_connect($socket, $address, $port);           // ���� ���� �� $result�� ���Ӱ� ���� //
		 if ($result == false) {
			 $retmess['regTm']='ERROR_81' ;
		 }

		$i = $this->input->raw_input_stream ;  //�������� �ϴ� ���� //
		socket_write($socket, $i, strlen($i)); // ������ �������� ������ ���ɾ� //
		
		//echo "<br>";     
		//$input = socket_read($socket, 1024) or die("Could not read from Socket\n");  // �������� ���� ���� REQUEST ������ $input�� ���� //
		//echo "<br>";
		//echo $input;  //REQUEST ���� ���//
		socket_close($socket);

		$this->set_response($retmess, REST_Controller::HTTP_OK); 


	} // cmd_post()

	

	//{ "type": "res", "farmNo": "1387", "icNo": "I1", "cmdString": [ { "eqId": "W1", "wateramt": "67" },{ "eqId": "L2", "pigcnt": "62", "aveday": "63", "stkg": "64", "wateramtsec": "65", "feedamt": "66", "wateramt": "67", "grpstday": "2019-08-07" } ] }

	//{ "type": "req", "farmNo": "1387", "icNo": "I1", "cmdString": [ { "eqId": "W1", "wateramt": "67" },{ "eqId": "L2", "pigcnt": "62", "aveday": "63", "stkg": "64", "wateramtsec": "65", "feedamt": "66", "wateramt": "67", "grpstday": "2019-08-07" } ] }
	public function cmd_post()
	{

		$retmess = [
		'type' => "res",
			];

		$resarraycmd = array() ; 

		$retvalcmd = array() ; 
		

		$cmdkey = array() ; 
		$cmdvalue = array() ; 

		$find_type="none";
		$find_farmno="none";
		$find_icno="none";
		$find_equno="none";
		$find_cmd="none";
		$find_value="none";
		$find_time="none";
	
		$find_ok=0;
	
		$remoteip = $_SERVER['REMOTE_ADDR'];
		
		$recip = array(
				'remoteip' => $remoteip
		);

		$find_type = $this->post('type') ;
		$find_farmno =  $this->post('farmNo') ;
		$find_icno =  $this->post('icNo') ;
		
		$find_cmdstring= $this->post('cmdString');
		$find_time= $this->post('regTm');
		
		$cmd_hcode = 0; 

		if( $find_type=="req" ) $cmd_hcode= 1;  
		if( $find_type=="set" ) $cmd_hcode= 2;  
		if( $find_type=="res" ) $cmd_hcode= 3; 
		

		//$pyoung = preg_replace("/[^0-9]*/s", "", $str);    ���ڸ� ����

		if( $cmd_hcode == 0 ) // error
		{
			$retmess['farmNo']=$find_farmno ;
			$retmess['icNo']=$find_icno ;
			$retmess['eqId']=$find_equno ;
			$retmess['cmdString']=$find_cmd ;
			$retmess['value']=$find_value ;
			$retmess['regTm']="ERROR_51" ;
			
			$this->set_response($retmess, REST_Controller::HTTP_OK); 

		} else {

			if( $cmd_hcode == 1 ) // req ��û ��Ŷ
			{
				// ������ ��񿡼� ��ȸ�Ͽ� Ŀ�ǵ��׸��� ã�ƺ���. all �ΰ�� ����  
				
				$retmess['farmNo']=$find_farmno ;
				$retmess['icNo']= $find_icno ;
//				$retmess['eqId']=$find_equno;//preg_replace("/[^a-zA-Z/s", "", $find_equno)  ;//this->onlyHanAlpha($find_equno) ;
				if( is_array($find_cmdstring) )	
				{

					foreach ($find_cmdstring as $key => $value)
					{					
						//$find_EQ_ID=$value['eqId'] ;
						$objarraycmd = array() ; 
						if( is_array($value) )	
						{
							
							$cmdkey = array_keys($value) ;
							$cmdvalue = array_values($value) ;
							//$DEVID = 'F'.$find_farmno.$find_icno.$cmdvalue[0];
							$eqType='none';
							$eqId='none';
							$find_eqId=0;

							for( $idx=0; $idx < count($cmdkey) ;$idx++ )
							{
								if( strcmp($cmdkey[$idx],'eqId' ) == 0 )
								{
									$eqType = preg_replace("/[^a-zA-Z]*/s", "", $cmdvalue[$idx]);//this->onlyHanAlpha( $cmdvalue[$idx] ) ;
									$eqId = preg_replace("/[^0-9]*/s", "", $cmdvalue[$idx])  ; //preg_replace("/[^0-9]*/s", "", $cmdvalue[$idx])  ;
									$find_eqId=1;
									break;
								}
						
							}

							array_push($cmdkey,'updateTm') ;
							array_push($cmdvalue,'1999-01-01 00:00:00') ;
							
							if( $find_eqId == 1)	 
							{
								// ������̱��� ��� ���� ó�� 
								if( $eqType=='E' )
								{
									$cntDev = $this->getCountDeviceE($eqId);
									for( $eidx=0 ; $eidx < $cntDev ;$eidx++)
									{
										$objequlist = array() ; 
										$getinfo = $this->getEtypeDeviceValue($eqId,$eidx);
										$objequlist["eqId"]="E".$eqId;
										foreach ($getinfo as $row)
										{
											$objequlist[ $row->CMD_COLUMN ]=$row->SET_VALUE ;
										}
										
										array_push( $resarraycmd, $objequlist ) ;
									}


								} else {
								
									// �Ϲ� ��ġ�� ��� ó�� 
									for( $idx=0; $idx < count($cmdkey) ;$idx++)
									{
										if( strcmp($cmdkey[$idx],'eqId' ) == 0 ) $objarraycmd[$cmdkey[$idx]] = $cmdvalue[$idx] ;
										else {
											
											//$DEVID = 'F'.$find_farmno.$find_icno.$eqType.$eqId.$cmdkey[$idx];
											
											if( strcmp($cmdkey[$idx],'updateTm' ) == 0 )
											{
												$objarraycmd[$cmdkey[$idx]] = $this->getDeviceValue($find_farmno,$find_icno,$eqType,$eqId,$cmdkey[$idx]);

												if( strcmp($objarraycmd[$cmdkey[$idx]],'0' ) == 0 )
												{
													// �ٸ� �����ʵ��� ������Ʈ �ð��� ������ 
													for( $idx2=0; $idx2 < count($cmdkey) ;$idx2++ )
													{
														if( strcmp($cmdkey[$idx2],'eqId' ) != 0 && strcmp($cmdkey[$idx2],'updateTm' ) != 0 )
														{
															$objarraycmd[$cmdkey[$idx]] = $this->getDeviceDate($find_farmno,$find_icno,$eqType,$eqId,$cmdkey[$idx2]);
														}
													
													}
												}

											} else 
												$objarraycmd[$cmdkey[$idx]] = $this->getDeviceValue($find_farmno,$find_icno,$eqType,$eqId,$cmdkey[$idx]);

											}
								
									}
									array_push( $resarraycmd, $objarraycmd ) ;
								}//if( $eqType=='E' )

								
							}
							//$retmess['cmdString']=$objarraycmd ;
						} else {
							$retmess['cmdString']=$find_cmd ;
							$find_value='11';
							//if( $this->search_cmd('W','R',$find_cmd) ) $retmess['reqTm']='find';
							//else $retmess['reqTm']='not find';

						}
					}


				} // isarray
				$retmess['cmdString']= $resarraycmd;

				//$retmess['value']=$find_value ;
				//$retmess['reqTm']= $find_time ;
				$this->set_response($retmess, REST_Controller::HTTP_OK); 
				return;
			} // req 

			
			if( $cmd_hcode == 2 ) // set ������Ŷ
			{
				// ������ ��񿡼� ��ȸ�Ͽ� Ŀ�ǵ��׸��� ã�ƺ���. all �ΰ�� ����  
				
				// ��� ���Ͽ� ���� ����
				
				$address = "119.205.221.143";                                                 // ������ IP //
				$port = 5100;                                                                         // ������ PORT //

				$query = $this->db->get('TE_ICT_CONFIG');
				
				if ($query->num_rows()>0)
				{
					//echo '<script>alert("ok!");</script>';
					$row = $query->row();

					$address=$row->IC_IP;
					$port=(int)$row->IC_PORT;
					
				} else $address = $_SERVER["SERVER_ADDR"] ;


				 $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP); // TCP ��ſ� ���� ���� //
				 if ($socket == false) {
					 $retmess['error']='ERROR_80' ;
					 return;	
				 } 
				 
				$result = socket_connect($socket, $address, $port);           // ���� ���� �� $result�� ���Ӱ� ���� //
				 if ($result == false) {
					 $retmess['error']='ERROR_81' ;
					 return ;
				 }

				$i = $this->input->raw_input_stream ;  //�������� �ϴ� ���� //
				socket_write($socket, $i, strlen($i)); // ������ �������� ������ ���ɾ� //
				
				socket_close($socket);
/*				
				// ��� �������� ��� ���� ��� 
			
				$retmess['farmNo']=$find_farmno ;
				$retmess['icNo']= $find_icno ;

				if( is_array($find_cmdstring) )	
				{

					foreach ($find_cmdstring as $key => $value)
					{					
						$find_EQ_ID=$value['eqId'] ;
						$objarraycmd = array() ; 
						if( is_array($value) )	
						{
							
							$cmdkey = array_keys($value) ;
							$cmdvalue = array_values($value) ;
							$DEVID = 'F'.$find_farmno.$find_icno.$cmdvalue[0];
							
							array_push($cmdkey,'updateTm') ;
							array_push($cmdvalue,'1999-01-01 00:00:00') ;

							for( $idx=0; $idx < count($cmdkey) ;$idx++)
							{

								if( $idx==0 ) $objarraycmd[$cmdkey[$idx]] = $cmdvalue[$idx] ;
									else {
									
										$objarraycmd[$cmdkey[$idx]] = $this->setDeviceValue($find_farmno,$DEVID,$cmdkey[$idx],$cmdvalue[$idx]);

									}
						
							}
							
							array_push( $resarraycmd, $objarraycmd ) ;
							//$retmess['cmdString']=$objarraycmd ;
						} else {
							$retmess['cmdString']=$find_cmd ;
							$find_value='11';
							//if( $this->search_cmd('W','R',$find_cmd) ) $retmess['reqTm']='find';
							//else $retmess['reqTm']='not find';

						}
					}


				}
				$retmess['cmdString']= $resarraycmd;
				//$retmess['value']=$find_value ;
				$retmess['reqTm']= $find_time ;
				
*/				 $retmess['socketip']=$address ;
				
				return;

			} // set 
		
		}


	} // cmd_post()


/*
CREATE TABLE TE_DEVICE_LIST
(
  `FARM_NO` varchar(10) NOT NULL COMMENT '�����ȣ',
  `IC_NO` varchar(32) NOT NULL COMMENT '����������ġID',
  `EQ_TYPE` varchar(6) NOT NULL COMMENT '��ġ ����',
  `EQ_ID` varchar(10) NOT NULL COMMENT '��ġID',
  `EQ_COM_TYPE` varchar(1) NOT NULL COMMENT '��Ź�� T,2,3',
  `ENABLE_YN` varchar(1) NOT NULL COMMENT '���ۿ��� Y,N',
  `SEND_CYCLE` varchar(10) NOT NULL COMMENT '�����ֱ�',
  `DONSA_CODE` varchar(6) NOT NULL COMMENT '�����ڵ�',
  `LOC_CODE` varchar(6) NOT NULL COMMENT '�����ڵ�',
  `USE_YN` varchar(1) NOT NULL COMMENT '��뿩��',
  `ETC` varchar(128) NOT NULL COMMENT '��Ÿ����',
  `LOG_INS_DT`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`FARM_NO`,`IC_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='��ġ�������';
*/

//{ "type": "set", "farmNo": "1387", "icNo": "I1", "devList": [{ "IC_NO": "F1387I1W1", "EQ_TYPE": "W","EQ_ID": "1","EQ_COM_TYPE": "T", "ENABLE_YN": "Y","SEND_CYCLE": "10", "DONSA_CODE": "11","LOC_CODE": "11", "USE_YN": "Y","ETC": "NONE", "LOG_INS_DT": "2019-07-27 09:11:11"  },{ "IC_NO": "F1387I1W2", "EQ_TYPE": "W","EQ_ID": "2","EQ_COM_TYPE": "T", "ENABLE_YN": "N","SEND_CYCLE": "11", "DONSA_CODE": "11","LOC_CODE": "12", "USE_YN": "Y","ETC": "NONE", "LOG_INS_DT": "2019-07-27 09:11:11"  }], "regTm": "20190722_160802" }


//{ "type": "req", "farmNo": "1387", "icNo": "I1", "devList": [{ "IC_NO": "F1387I1W1", "EQ_TYPE": "W","EQ_ID": "1","EQ_COM_TYPE": "T", "ENABLE_YN": "Y","SEND_CYCLE": "10", "DONSA_CODE": "11","LOC_CODE": "11", "USE_YN": "Y","ETC": "NONE", "LOG_INS_DT": "2019-07-27 09:11:11"  },{ "IC_NO": "F1387I1W2", "EQ_TYPE": "W","EQ_ID": "2","EQ_COM_TYPE": "T", "ENABLE_YN": "N","SEND_CYCLE": "11", "DONSA_CODE": "11","LOC_CODE": "12", "USE_YN": "Y","ETC": "NONE", "LOG_INS_DT": "2019-07-27 09:11:11"  }], "regTm": "20190722_160802" }

	public function device_post()
	{

		$retmess = [
		'type' => "res",
			];		

		$resarraycmd = array() ; 

		$find_FARM_NO="none";
		$find_ICNO="none";
		$find_TYPE="none";
		$find_IC_NO="none";
		$find_EQ_TYPE="none";
		$find_EQ_ID="none";
		$find_EQ_COM_TYPE="none";
		$find_ENABLE_YN="none";
		$find_SEND_CYCLE="none";
		$find_DONSA_CODE="none";
		$find_LOC_CODE="none";
		$find_USE_YN="none";
		$find_ETC="none";
		$find_LOG_INS_DT="none";
		
	
		
		$find_TYPE=$this->post('type') ;
		 
		$find_FARM_NO=$this->post('farmNo') ;
		$find_ICNO=$this->post('icNo') ;
		$find_DEVLIST=$this->post('devList') ;
		
		if( $find_TYPE == 'req' )
		{
			//$this->db->where('IC_NO', $find_IC_NO );
			$query = $this->db->get('TE_DEVICE_LIST');

		
			if ($query->num_rows()>0)
			{
				foreach ($query->result() as $row)
				{
					//echo $row->title;

						
					$detarray= array(
						'FARM_NO' => $row->FARM_NO, 
						'IC_NO' =>$row->IC_NO,
						'EQ_TYPE' =>$row->EQ_TYPE,
						'EQ_ID' =>$row->EQ_ID,
						'SEND_CYCLE' =>$row->SEND_CYCLE,
						'DONSA_CODE'=>$row->DONSA_CODE, 
						'LOC_CODE'=>$row->LOC_CODE,
						'USE_YN'=>$row->USE_YN,
						'ETC'=>$row->ETC,
						'LOG_INS_DT'=>$row->LOG_INS_DT,
			
					);

					array_push( $resarraycmd, $detarray ) ;

				}
			}		
			$retmess['devList']=$resarraycmd ;

			$retmess['farmNo']= $find_FARM_NO ;
			$retmess['icNo']=$find_ICNO ;
			$this->set_response($retmess, REST_Controller::HTTP_OK); 

			return ;

		}

		// set ���� ó�� 
		if( is_array($find_DEVLIST) )	
		{

			foreach ($find_DEVLIST as $key => $value)
			{
				
				
				$find_IC_NO=$value['IC_NO'] ;
				$find_EQ_TYPE=$value['EQ_TYPE'] ;
				$find_EQ_ID=$value['EQ_ID'] ;
				$find_SEND_CYCLE=$value['SEND_CYCLE'] ;
				$find_DONSA_CODE=$value['DONSA_CODE'] ;
				$find_LOC_CODE=$value['LOC_CODE'] ;
				$find_USE_YN=$value['USE_YN'] ;
				$find_ETC=$value['ETC'] ;
				$find_LOG_INS_DT=$value['LOG_INS_DT'] ;
				
				
				$sqlcmd= array(
					'FARM_NO' => $find_FARM_NO, 
					'IC_NO' =>$find_IC_NO,
					'EQ_TYPE' =>$find_EQ_TYPE,
					'EQ_ID' =>$find_EQ_ID,
					'SEND_CYCLE' =>$find_SEND_CYCLE,
					'DONSA_CODE'=>$find_DONSA_CODE, 
					'LOC_CODE'=>$find_LOC_CODE,
					'USE_YN'=>$find_USE_YN,
					'ETC'=>$find_ETC,
					//'LOG_INS_DT'=>$find_LOG_INS_DT,
					
				
				);

				
				$this->db->where('IC_NO', $find_IC_NO );
				$query = $this->db->get('TE_DEVICE_LIST');

				if ($query->num_rows()>0)
				{
					
					if( $find_USE_YN == 'D' )
					{
						$detarray = array(

						'IC_NO' =>$find_IC_NO,
						'RESULT' =>"DEL",
						);

						array_push( $resarraycmd, $detarray ) ;
						//echo '<script>alert("ok!");</script>';
						$this->db->where('FARM_NO', $find_FARM_NO);
						$this->db->where('IC_NO', $find_IC_NO);
						$this->db->delete('TE_DEVICE_LIST');
					} else {

						$detarray = array(

						'IC_NO' =>$find_IC_NO,
						'RESULT' =>"UPDATED",
						);

						array_push( $resarraycmd, $detarray ) ;
						//echo '<script>alert("ok!");</script>';
						$this->db->where('FARM_NO', $find_FARM_NO);
						$this->db->where('IC_NO', $find_IC_NO);
						$this->db->update('TE_DEVICE_LIST', $sqlcmd);

					}

				} else {
					
					if( $find_USE_YN != 'D' )
					{
						$detarray = array(

						'IC_NO' =>$find_IC_NO,
						'RESULT' =>"ADD",
						);	
						array_push( $resarraycmd, $detarray ) ;
						
						$this->db->insert('TE_DEVICE_LIST', $sqlcmd);				
					}
					
				}

				$retmess['devList']=$resarraycmd ;
			
			};

		} else {

				$retmess['devList']=$resarraycmd ;
		}
		
		$retmess['farmNo']= $find_FARM_NO ;
		$retmess['icNo']=$find_ICNO ;
		


		$this->set_response($retmess, REST_Controller::HTTP_OK); 

	}	

} // class end

