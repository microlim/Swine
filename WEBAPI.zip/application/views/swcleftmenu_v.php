<center>
<table border="0"  > <!-- 첫번째 테이블 -->

    <tr style="width:10px">  
        
		<td valign="top"> <!-- 왼쪽 달력 및 행사 리스트 -->
			
	
		
		</td><!-- ./왼쪽 달력 및 행사 리스트 -->