    </tr> 
</table><!-- ./첫번째 테이블 -->

</div>

<script type="text/javascript" src="/FTEK/include/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="/FTEK/include/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/FTEK/include/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="/FTEK/include/js/locales/bootstrap-datetimepicker.ko.js" charset="UTF-8"></script>

<script type="text/javascript">
 
Date.prototype.format = function(f) {
    if (!this.valueOf()) return " ";
 
    var weekName = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var d = this;
     
    return f.replace(/(yyyy|yy|MM|dd|E|hh|mm|ss|a\/p)/gi, function($1) {
        switch ($1) {
            case "yyyy": return d.getFullYear();
            case "yy": return (d.getFullYear() % 1000).zf(2);
            case "MM": return (d.getMonth() + 1).zf(2);
            case "dd": return d.getDate().zf(2);
            case "E": return weekName[d.getDay()];
            case "HH": return d.getHours().zf(2);
            case "hh": return ((h = d.getHours() % 12) ? h : 12).zf(2);
            case "mm": return d.getMinutes().zf(2);
            case "ss": return d.getSeconds().zf(2);
            case "a/p": return d.getHours() < 12 ? "오전" : "오후";
            default: return $1;
        }
    });
};
 
String.prototype.string = function(len){var s = '', i = 0; while (i++ < len) { s += this; } return s;};
String.prototype.zf = function(len){return "0".string(len - this.length) + this;};
Number.prototype.zf = function(len){return this.toString().zf(len);};

function goPage(type,accnum) 
{ 
	//alert("http://127.0.0.1:8080/pricelist/"+accnum ) ; 
	if(type==0 ) location.href="http://127.0.0.1:8080/pricelist/"+accnum; 
	if(type==1 ) location.href="http://127.0.0.1:8080/pricelist1/"+accnum; 
	if(type==2 ) location.href="http://127.0.0.1:8080/pricelist2/"+accnum; 
	
}


$('.dropdown-menu a').click(function(){
    $('#input03').text($(this).text());
  });

$('.dropdown-menu a').click(function(){
    $('#ddMenu2sel').text($(this).text());
  });

$('#llist_datepicker').datetimepicker({
	language:  'ko',
	startView: 2,
	minView: 2,
	inline: true,
	sideBySide: false
});
	

$('#llist_datepicker').datetimepicker()
  .on('changeDate', function(e){
    
  });

$('#datetimepicker12').datetimepicker({
	language:  'ko',
	startView: 2,
	minView: 2,
	inline: true,
	sideBySide: false
});


$('#inform_adata').datetimepicker({
	language:  'ko',
	format:'yyyy-mm-dd',
	weekStart: 1,
	todayBtn:  1,
	autoclose: 1,
	todayHighlight: 1,
	startView: 2,
	minView: 2,
	forceParse: 0,
	
});

$('#inform_rdata1').datetimepicker({
	language:  'ko',
	format:'yyyy-mm-dd hh:ii DD',
	weekStart: 1,
	todayBtn:  1,
	autoclose: 1,
	todayHighlight: 1,
	startView: 2,
	minView: 1,
	forceParse: 0,
	
});
$('#inform_rdata2').datetimepicker({
	language:  'ko',
	format:'yyyy-mm-dd hh:ii DD',
	weekStart: 1,
	todayBtn:  1,
	autoclose: 1,
	todayHighlight: 1,
	startView: 2,
	minView: 1,
	forceParse: 0,
	
});

</script>




</body>

</html>
