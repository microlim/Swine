	<footer id="footer">
		<blockquote>
			
		<blockquote>
	</footer>

</div>

<script type="text/javascript" src="/FTEK/include/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="/FTEK/include/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/FTEK/include/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="/FTEK/include/js/locales/bootstrap-datetimepicker.ko.js" charset="UTF-8"></script>

</body>
</html>