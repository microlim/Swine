	<?php
	if( @$this->session->userdata['logged_in'] == TRUE )
	{
	?>
<td valign="top"> <!-- 오른쪽 인폼 칸  -->
<div class="page-header">
  <h1>주문 건별 로그<small>Log</small></h1>

<table cellspacing="0" cellpadding="0" border="0">
<tr>
<td>매장명:</td>
<td><?php echo $member;?></td>
<td width="20px"></td>
<td>조회날짜:</td>
<td><?php echo $sdate;?></td>

</tr>
</table>
</div>
		<table cellspacing="0" cellpadding="0" class="table table-striped">
			<thead>
				<tr>
					<th scope="col">shop ID</th>
					<th scope="col">Date</th>
					<th scope="col">번호</th>
					<th scope="col">가격</th>
					<th scope="col">대행사</th>
					<th scope="col">주소</th>
					<th scope="col">기타</th>
				</tr>
			</thead>
			<tbody>
<?php
foreach ($list as $lt)
{
?>
				<tr>
					<td><?php echo $lt->fuid; ?></td>
					<td><?php echo $lt->ddate; ?></td>
					<td><?php echo $lt->tnum; ?></td>
					<td><?php echo $lt->amount; ?></td>
					<td><?php echo $lt->dcode; ?></td>
					<td><?php echo $lt->addr; ?></td>
					<td><?php echo $lt->etc; ?></td>
				</tr>
<?php
}
?>

			</tbody>
			<tfoot>
				<tr>
					
				</tr>
			</tfoot>
		</table>  

</td> <!-- ./오른쪽 인폼 칸  -->

	<?php
	} else {
	?>
	
	
	<?php
	}
	?>		

