<td valign="top"> <!-- 오른쪽 인폼 칸  -->	
	
<article id="board_area">
	<header>
		<h1>기본설정</h1>
	</header>
	
	<form class="form-horizontal" method="post" action="" id="write_action">
	  <fieldset>
		<div class="control-group">

		  <label class="control-label" for="input02">농장번호</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="FARM_NO" name="FARM_NO" value="<?php echo $data->FARM_NO;?>">
			<p class="help-block"></p>
		  </div>		  
		  <label class="control-label" for="input03">통합제어기번호</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="IC_NO" name="IC_NO" value="<?php echo $data->IC_NO;?>">
			<p class="help-block"></p>
		  </div>
		  
		  <label class="control-label" for="input01">IP</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="IC_IP" name="IC_IP" value="<?php echo $data->IC_IP;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">TCP PORT</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="IC_PORT" name="IC_PORT" value="<?php echo $data->IC_PORT;?>">
			<p class="help-block"></p>
		  </div>
		
		  <div class="form-actions">
			<input type="submit" class="btn btn-primary" id="write_btn" value="변경"></button>
		  </div>
		</div>
	  </fieldset>


	</form>

</article>


</td> <!-- ./오른쪽 인폼 칸  -->

