<!doctype html>
<html>
 <head>
  <meta charset="UTF-8">

  <title>Document</title>
 </head>
 <body>
		<table cellspacing="0" cellpadding="0" class="table table-striped">
			<thead>
				<tr>
					<th scope="col">번호</th>
					<th scope="col">내용</th>
					<th scope="col">시작일</th>
					<th scope="col">종료일</th>
				</tr>
			</thead>
			<tbody>
<?php
foreach ($list as $lt)
{
?>
				<tr>
					<th scope="row">
						<?php echo $lt->id;?>
					</th>
					<td><a rel="external" href="/todo/index.php/main/view/<?php echo $lt->id;?>"><?php echo $lt->content;?></a></td>
					<td><?php $dtime = new DateTime($lt->created_on); echo $dtime->format("Y-m-d"); ?></td>
					<td><?php $etime = new DateTime($lt->due_date); echo $etime->format("Y-m-d"); ?></td>
				</tr>
<?php
}
?>

			</tbody>
			<tfoot>
				<tr>
					<th colspan="4"><a href="/todo/index.php/main/write/" class="btn btn-success">쓰기</a></th>
				</tr>
			</tfoot>
		</table>  
 </body>
</html>
