
			
<td valign="top"> <!-- 오른쪽 인폼 칸  -->
<div class="page-header">
  <h1>설치장비 목록<small> Device List</small></h1>
</div>


<?php
/*
foreach ( $nmdata as $row )
{
	echo $row->EQ_NM;
}
*/


/*
function getdb_DevNM_getFind($eqtype)
{
	$result = 'none' ;
	$getnmdata= $nmdata;
	foreach ( $getnmdata as $row )
	{
		if( strcmp($eqtype,$row->EQ_TYPE) == 0)
		{
			$result = $row->EQ_NM;
			echo $result ;
		}
	}

	return $result;
}
*/
?>
<form class="form-horizontal" method="post" action="" id="write_action">
  <fieldset>
	<div class="control-group">
	  <label class="control-label" for="input02">현재 전체 주기:</label>	
	  <label class="control-label" for="input02"><?php echo $list[0]->SEND_CYCLE;?></label>
	  <label class="control-label" for="input02"> 분</label>	
	</div>

	<div class="control-group">
	  <label class="control-label" for="input02">전체 주기 설정:</label>
	  <input type="text" class="input-xlarge" id="ALL_CYCLE" name="ALL_CYCLE" value="<?php echo $list[0]->SEND_CYCLE;?>">
	  <label class="control-label" for="input02"> 분</label>	
	  <input type="submit" class="btn btn-primary" id="write_btn" value="적용"></button>
	</div>
  </fieldset>


</form>
<table cellspacing="0" cellpadding="0" class="table table-striped">
	<thead>
		<tr>
			<th scope="col">장치명</th>
			<th scope="col">장치번호</th>
			<th scope="col">전송주기</th>
			<th scope="col">돈사코드</th>
			<th scope="col">돈방코드</th>
			<th scope="col">사용여부</th>
		</tr>
	</thead>
	<tbody>
<?php
foreach ($list as $lt)
{
?>
		<tr>
			<td><?php echo $lt->HNAME?></td>
			<td><a rel="external" href="/ezfarm/API/index.php/main/devinfo/<?php echo $lt->EQ_TYPE;?>/<?php echo $lt->EQ_ID;?>"><?php echo $lt->EQ_TYPE.$lt->EQ_ID;?></a></td>
			<td><?php echo $lt->SEND_CYCLE;?></td>
			<td><?php echo $lt->DONSA_CODE;?></td>
			<td><?php echo $lt->LOC_CODE;?></td>
			<td><?php echo $lt->USE_YN;?></td>
		</tr>
<?php
}
?>

	</tbody>
	<tfoot>
		<tr>
			
		</tr>
	</tfoot>
</table>  

</td> <!-- ./오른쪽 인폼 칸  -->


