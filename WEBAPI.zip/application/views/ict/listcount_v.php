

<?php
if( @$this->session->userdata['logged_in'] == TRUE )
{
?>
	<td valign="top"> <!-- 오른쪽 인폼 칸  -->
	<div class="page-header">
	  <h1>자동입력 횟수<small> TODAY COUNT</small></h1>
	</div>

	<span>
	<?php 
	echo $sdate;
	echo " 자동입력 횟수:" ;
	echo $query->num_rows();
	
	?>
	</span>

	</td> <!-- ./오른쪽 인폼 칸  -->
<?php
} else {
?>

<?php
}
?>			




