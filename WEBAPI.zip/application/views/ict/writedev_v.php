<td valign="top"> <!-- 오른쪽 인폼 칸  -->	
	
<article id="board_area">
	<header>
		<h1>장비설정정보 (<?php echo $data->HNAME;?>)</h1>
	</header>
	
	<form class="form-horizontal" method="post" action="" id="write_action">
	  <fieldset>
		<div class="control-group">

		  <label class="control-label" for="input02">농장번호</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="FARM_NO" name="FARM_NO" value="<?php echo $data->FARM_NO;?>">
			<p class="help-block"></p>
		  </div>		  
		  <label class="control-label" for="input03">통합제어기번호</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="IC_NO" name="IC_NO" value="<?php echo $data->IC_NO;?>">
			<p class="help-block"></p>
		  </div>
		 
		  <label class="control-label" for="input01">장치명</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="EQ_NM" name="EQ_NM" value="<?php echo $nmdata;?>">
			<p class="help-block"></p>
		  </div>		  

		  <label class="control-label" for="input01">장치TYPE</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="EQ_TYPE" name="EQ_TYPE" value="<?php echo $data->EQ_TYPE;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">장치ID</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="EQ_ID" name="EQ_ID" value="<?php echo $data->EQ_ID;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">전송주기</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="SEND_CYCLE" name="SEND_CYCLE" value="<?php echo $data->SEND_CYCLE;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">돈사코드</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="DONSA_CODE" name="DONSA_CODE" value="<?php echo $data->DONSA_CODE;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">돈방코드</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="LOC_CODE" name="LOC_CODE" value="<?php echo $data->LOC_CODE;?>">
			<p class="help-block"></p>
		  </div>

		  <label class="control-label" for="input01">사용여부</label>
		  <div class="controls">
			<input type="text" class="input-xlarge" id="USE_YN" name="USE_YN" value="<?php echo $data->USE_YN;?>">
			<p class="help-block"></p>
		  </div>
		
		  <div class="form-actions">
			<input type="submit" class="btn btn-primary" id="write_btn" value="변경"></button>
		  </div>
		</div>
	  </fieldset>


	</form>

</article>


</td> <!-- ./오른쪽 인폼 칸  -->

