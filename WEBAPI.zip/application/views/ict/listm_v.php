
			
	<?php
	if( @$this->session->userdata['logged_in'] == TRUE )
	{
	?>
<td valign="top"> <!-- 오른쪽 인폼 칸  -->
<div class="page-header">
  <h1>배달 통계<small> Summary</small></h1>
</div>

<form  method="post" action="" id="write_action" >	

<table cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="200" valign='top'>
	<div class="from-group">
	<select class="form-control" id="shop_id" name="shop_id">
	<?php	
	 if( strcmp($shopname,'전체') == 0 ) 
		echo "<option value=\"0\" selected>전체</option>\n"	;
		else
		echo "<option value=\"0\">전체</option>\n"	;

	 for( $i=1; $i<count($member)+1; $i++)
	 {
		if( strcmp($member[$i-1]->shopname,$shopname) == 0 )
			echo "<option value=\"".$i."\" selected>".$member[$i-1]->shopname."</option>\n"	;
		else
			echo "<option value=\"".$i."\" >".$member[$i-1]->shopname."</option>\n"	;
	 }
	?>

	</select>
	</div>			
</td>
<td>
	
<div class="form-group">
	<div class='input-group date' id='inform_adata'>
		<input type='text' class="form-control" id="ac_date" name="ac_date" value="<?php echo $todate;?>">
		<span class="input-group-addon">
			<span class="glyphicon glyphicon-calendar">
			</span>
		</span>
	</div>
</div>
	
</td>
<td valign="top" width="20px">
</td>
<td valign="top">
<input type="submit" class="btn btn-primary" id="search_btn" value="검색">
<a href="/FTEK/index.php/main/monthsum/" class="btn btn-primary"><?php echo $todatemonth;?>월 재통계</a>
</td>
</tr>
</table>
</form>


<?php
/*--------------------
Title : 초간단 달력
---------------------*/

$YYYY = $todateyear; 
$MM = $todatemonth; 

$firstday_weeknum = date("w", mktime(0, 0, 0, $MM, 1, $YYYY)); 
$lastday = date("t", mktime(0, 0, 0, $MM, 1, $YYYY)); 


if($MM == 2) { 
    if(($YYYY % 4) == 0 && ($YYYY % 100) != 0 || ($YYYY % 400) == 0) { $lastday = 29; }
}

$td1 = "<TD width='90' align='center'><font size='2' align='center'><b>";
$td2 = "</b></font></TD><TD width='90' height='90' align='center'><font size='2' align='center'><b>";
$td3 = "</b></font></TD>\n";
?>
<table width="500">
<tr>
<td width="200" align="left"><?php echo "$YYYY";?>년<?php echo "$MM";?>월</td>
<td width="100" align="right"> 총합:</td>
<td width="200" align="left"><?php echo $totalcount;?></td>
</tr>
</table>

<?php
echo("<table border=1 cellspacing=0 cellpadding=2 bordercolorlight=#CCCCCC bordercolordark=#FFFFFF bgcolor=#FFFFFF><TR>\n");
echo($td1."<font color='red'>일</font>".$td2."월".$td2."화".$td2."수".$td2."목".$td2."금".$td2."<font color='green'>토</font>".$td3);
echo("</TR><TR>");

$week = 0;
for($i=0; $i < $firstday_weeknum; $i++) { echo("<TD>&nbsp;</TD>"); $week++; }
for($d=1; $d <= $lastday; $d++)
{

    if ($week == 7) { echo("</TR></TR>"); $week = 0; }
    $day = (date("j") == $d)? "<font color='deepink'><b>".$d."</b></font>":$d;
   
    echo("<TD wdith='90' height='90' >") ;
	echo("<p align='left'>") ;
	//$linkstr = "<a href='/FTEK/index.php/main/Daytotal/".$shopname."/".$YYYY."-".$MM."-".$d."'>";
	//echo $linkstr;
	echo $d;
	//echo("</a>");
	echo("</p>") ;
	echo("<p align='center'><font color='black'><b>");
	
	$linkstr = "<a href='/FTEK/index.php/main/Daytotal/".$shopname."/".$YYYY."-".$MM."-".$d."'>";
	echo $linkstr;
	echo $list[$d-1]->count;
	echo("</a>");
	echo("</b></font></p>") ;
	echo("</TD>\n");
	
	
    $week++;
}


for ($i=$week; $i < 7; $i++) { echo("<TD>&nbsp;</TD>\n"); }
echo("</TR>\n");
echo("</TABLE>\n"); 

?>



</td> <!-- ./오른쪽 인폼 칸  -->

	<?php
	} else {
	?>
	
	
	<?php
	}
	?>		





