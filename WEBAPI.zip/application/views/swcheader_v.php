<!DOCTYPE html>
<html>
<head>
    <title>통합제어기 환경설정</title>
    <link href="/ezfarm/API/include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="/ezfarm/API/include/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
</head>

<body>
<div id="main">

<nav class="navbar navbar-default">
  <div class="container-fluid">
    
	<!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">통합제어기</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

	<a href="/ezfarm/API/index.php/main/config/" class="btn btn-default navbar-btn" role="button">IP환경설정</a>	 
	<a href="/ezfarm/API/index.php/main/devlists/" class="btn btn-default navbar-btn" role="button">설치장비</a>	 
	<a href="/ezfarm/API/index.php/main/ICTrestart/" class="btn btn-default navbar-btn" role="button">재시작</a> 
	<!--

	<a href="/FTEK/index.php/main/listlog/" class="btn btn-default navbar-btn" role="button">금일로그</a>	
	-->
	

	<form class="navbar-form navbar-right">
	<div class="form-group">
	  <input type="text" class="form-control" placeholder="Search">
	</div>
	<button type="submit" class="btn btn-default">검색</button>
	</form>
	

	<div class="navbar-form navbar-right">
	</div><!-- /.navbar-collapse -->
	
	</div><!-- /.navbar-collapse -->

  </div><!-- /.container-fluid -->
</nav>