<!DOCTYPE html>
<html>
<head>
    <title>FTEK intranet</title>
    <link href="/FTEK/include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/FTEK/include/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <!-- Custom style -->
    <link rel="stylesheet" href="/FTEK/include/css/style.css" media="screen" title="no title" charset="utf-8">

</head>

<body>
<div id="main">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    
	<!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">FTEK intranet</a>
    </div>

  </div><!-- /.container-fluid -->
</nav>
